

<?php $__env->startSection('content'); ?>

<div class="container py-5">

    <h1>Welcome to Melodix</h1>

    <p>Your music database is connected!</p>

    <h3>Latest Songs</h3>

    <?php $__empty_1 = true; $__currentLoopData = $latestSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <p>
            <?php echo e($song->title); ?>

            — <?php echo e($song->artist->name ?? 'Unknown Artist'); ?>

        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No songs available yet.</p>
    <?php endif; ?>

    <h3>Latest Videos</h3>

    <?php $__empty_1 = true; $__currentLoopData = $latestVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <p><?php echo e($video->title); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No videos available yet.</p>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\cz 3\OneDrive\Desktop\Portfolio work\Webdesigning\Melodix E-project\Melodix\melodix-project\resources\views/home.blade.php ENDPATH**/ ?>