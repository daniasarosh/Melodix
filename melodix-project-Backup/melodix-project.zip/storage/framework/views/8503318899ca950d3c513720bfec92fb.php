<aside class="sidebar app-sidebar">
    <a href="<?php echo e(url('/')); ?>" class="logo sidebar-logo" aria-label="Melodix home">
        <img src="<?php echo e(asset('images/melodix-icon.svg')); ?>" alt="Melodix">
    </a>

    <div class="sidebar-group">
        <p class="nav-title">Discover</p>
        <nav class="nav sidebar-nav" aria-label="Main navigation">
            <a href="<?php echo e(url('/')); ?>" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">
                <i class="bi bi-house-door"></i><span>Home</span>
            </a>
            <a href="<?php echo e(url('/browse')); ?>" class="<?php echo e(request()->is('browse*') ? 'active' : ''); ?>">
                <i class="bi bi-compass"></i><span>Browse</span>
            </a>
            <a href="<?php echo e(url('/artists')); ?>" class="<?php echo e(request()->is('artists*') ? 'active' : ''); ?>">
                <i class="bi bi-mic"></i><span>Artists</span>
            </a>
            <a href="<?php echo e(url('/albums')); ?>" class="<?php echo e(request()->is('albums*') ? 'active' : ''); ?>">
                <i class="bi bi-disc"></i><span>Albums</span>
            </a>
            <a href="<?php echo e(url('/videos')); ?>" class="<?php echo e(request()->is('videos*') ? 'active' : ''); ?>">
                <i class="bi bi-play-btn"></i><span>Music Videos</span>
            </a>
        </nav>
    </div>

    <div class="sidebar-group">
        <p class="nav-title">Your music</p>
        <nav class="nav sidebar-nav" aria-label="Your music navigation">
            <a href="<?php echo e(url('/playlists')); ?>" class="<?php echo e(request()->is('playlists*') ? 'active' : ''); ?>">
                <i class="bi bi-music-note-list"></i><span>Playlists</span>
            </a>
            <a href="<?php echo e(url('/my-playlists')); ?>" class="<?php echo e(request()->is('my-playlists*') ? 'active' : ''); ?>">
                <i class="bi bi-collection-play"></i><span>My Library</span>
            </a>
        </nav>
    </div>

    <div class="sidebar-bottom">
        <span class="sidebar-note"><i class="bi bi-soundwave"></i> Your sound. Your space.</span>
    </div>
</aside>
<?php /**PATH C:\Users\cz 3\OneDrive\Desktop\Portfolio work\Webdesigning\Melodix E-project\Melodix\melodix-project\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>