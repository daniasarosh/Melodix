<footer class="app-footer">
    <div class="footer-brand">
        <img src="<?php echo e(asset('images/brand/melodix-icon.svg')); ?>" alt="" aria-hidden="true">
        <span>MELODIX</span>
    </div>
    <p>Music brings every moment to life.</p>
    <small>&copy; <?php echo e(date('Y')); ?> Melodix. All rights reserved.</small>
</footer>
<?php /**PATH C:\Users\cz 3\OneDrive\Desktop\Portfolio work\Webdesigning\Melodix E-project\Melodix\melodix-project\resources\views/partials/footer.blade.php ENDPATH**/ ?>