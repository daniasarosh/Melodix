<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Language extends Model
{
    protected $fillable = ['name'];

    public function songs(): HasMany
    {
        return $this->hasMany(Song::class);
    }

    public function videos(): HasMany
    {
        return $this->hasMany(Video::class);
    }
}
